Containers
----------

 * :ref:`pkg.sparsehash` - C++ associative containers
