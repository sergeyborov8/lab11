.. spelling::

  Filesystem

Filesystem
----------

 - :ref:`pkg.hdf5` -  data model, library, and file format for storing and managing data.
 - :ref:`pkg.tinydir` - Lightweight, portable and easy to integrate C directory and file reader
