Media
-----

 - :ref:`pkg.Jpeg` -  library for JPEG image compression.
 - :ref:`pkg.libyuv` - YUV scaling and conversion functionality.
 - :ref:`pkg.PNG` - library for use in applications that read, create, and manipulate PNG (Portable Network Graphics) raster image files.
 - :ref:`pkg.TIFF`
