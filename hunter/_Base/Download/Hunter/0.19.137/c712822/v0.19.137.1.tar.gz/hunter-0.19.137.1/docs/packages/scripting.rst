Scripting
---------

 - :ref:`pkg.Lua` - powerful, efficient, lightweight, embeddable scripting language.

