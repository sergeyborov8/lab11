.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

Simple example
--------------

.. admonition:: Examples on GitHub

  * `Tiny project with GTest <https://github.com/forexample/hunter-simple>`_
