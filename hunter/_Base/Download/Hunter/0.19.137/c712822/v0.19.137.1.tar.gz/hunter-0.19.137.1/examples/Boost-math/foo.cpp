#include <boost/math/tr1.hpp>

int main() {
}

