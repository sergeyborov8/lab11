#include <capnp/message.h>

int main() {
    ::capnp::MallocMessageBuilder message;

    return 0;
}
