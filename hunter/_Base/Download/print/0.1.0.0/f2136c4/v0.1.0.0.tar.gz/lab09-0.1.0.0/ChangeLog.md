* 20.10.17 sergeyborov8 <sergborovkov@gmail.com> 0.1.0.0
- Initial RPM release
