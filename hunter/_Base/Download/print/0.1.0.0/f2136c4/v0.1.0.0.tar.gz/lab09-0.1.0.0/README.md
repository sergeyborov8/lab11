[![Build Status](https://travis-ci.org/sergeyborov8/lab08.svg?branch=master)](https://travis-ci.org/sergeyborov8/lab08)
